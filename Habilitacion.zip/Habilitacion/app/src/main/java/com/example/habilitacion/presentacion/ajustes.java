package com.example.habilitacion.presentacion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.habilitacion.R;

public class ajustes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajustes);
    }
}