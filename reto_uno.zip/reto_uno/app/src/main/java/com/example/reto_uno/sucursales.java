package com.example.reto_uno;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class sucursales extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sucursales);
    }
}